<?php

$server   = "sql211.hostfree.pw";
$user     = "epree_19824997";
$password = "742699";
$db       = "epree_19824997_moviny";

$mysqli = new mysqli($server, $user, $password, $db);
if(mysqli_connect_errno()){
	echo mysqli_connect_error();
}
?>