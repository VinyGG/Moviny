<?php
$valor = $_POST['my_rating2'];
echo "valor: " . $valor;
?>