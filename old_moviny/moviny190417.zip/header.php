
    <center>
      <a href="index.php"><img src="imgs/logo_203x91.png" width="200" height="85" alt="logo"></a>
      </p>
      <p>
      <table width="800" align="center" cellpadding="0" id="centertb" >
        <tr>
          <th width="701" align="center" valign="middle" nowrap="nowrap" class="style" id="centertb" scope="col" border="0"> <table id="tbmenu" align="center" width="700" border="0" bgcolor="#fff" cellpadding="5">
              <tbody>
              <tr>
                <td align="center"></td>
                <td align="center"></td>
                <td align="center" colspan="4"></td>
              </tr>
              <tr>
                <td align="center"><a href="index.php" style="text-decoration:none; color: #004444">BUSCAR</a></td>
                <td align="center"><a href="movies.php" style="text-decoration:none; color: #004444">FILMES</a></td>
                <td align="center"><a href="addmovie.php" style="text-decoration:none; color: #004444">ADICIONAR FILME</a></td>
              </tr>
              <tr>
                <td width="223" align="center"></td>
                <td width="223" align="center"></td>
                <td width="223" colspan="4" align="center"></td>
              </tr>
            </tbody>
            </table>
      </table>
    </center>
